document.addEventListener("DOMContentLoaded", function () {
  // دریافت اطلاعات سبد خرید از localStorage
  const cartItems = JSON.parse(localStorage.getItem("cartItems")) || [];

  // نمایش اطلاعات سبد خرید
  const cartSummary = document.getElementById("cart-summary");
  const amountInput = document.getElementById("amount");

  if (cartSummary && amountInput) {
    if (cartItems.length === 0) {
      cartSummary.innerHTML = "<p>سبد خرید شما خالی است.</p>";
    } else {
      let total = 0;
      cartSummary.innerHTML = "<h3>سبد خرید شما:</h3>";
      cartItems.forEach((item) => {
        cartSummary.innerHTML += `<p>${item.name} - ${item.price.toLocaleString()} تومان</p>`;
        total += item.price;
      });
      cartSummary.innerHTML += `<p><strong>مجموع: ${total.toLocaleString()} تومان</strong></p>`;

      // پر کردن خودکار فیلد مبلغ
      amountInput.value = total;
    }
  }

  // اعتبارسنجی فرم پرداخت
  const paymentForm = document.getElementById("payment-form");
  const errorMessage = document.getElementById("error-message");

  if (paymentForm) {
    paymentForm.addEventListener("submit", function (e) {
      e.preventDefault();

      // اعتبارسنجی شماره کارت
      const cardNumber = document.getElementById("card-number").value;
      if (cardNumber.length !== 16 || isNaN(cardNumber)) {
        errorMessage.textContent = "شماره کارت باید 16 رقم باشد.";
        errorMessage.style.display = "block";
        return;
      }

      // اعتبارسنجی تاریخ انقضا
      const expiryDate1 = document.getElementById("expiry-date1").value;
      const expiryDate2 = document.getElementById("expiry-date2").value;
      const expiryDate = expiryDate1 + "/" + expiryDate2;

      if (!/^\d{2}\/\d{2}$/.test(expiryDate)) {
        errorMessage.textContent = "تاریخ انقضا باید به فرمت MM/YY باشد.";
        errorMessage.style.display = "block";
        return;
      }

      // اعتبارسنجی CVV
      const cvv = document.getElementById("cvv").value;
      if (cvv.length < 3 || cvv.length > 4 || isNaN(cvv)) {
        errorMessage.textContent = "CVV باید 3 یا 4 رقم باشد.";
        errorMessage.style.display = "block";
        return;
      }

      // اگر همه چیز درست بود، فرم ارسال می‌شود
      errorMessage.style.display = "none";
      alert("پرداخت با موفقیت انجام شد!");

      // پاک کردن سبد خرید از localStorage
      localStorage.removeItem("cartItems");

      // هدایت به صفحه موفقیت
      window.location.href = "./success.html";
    });
  }
});