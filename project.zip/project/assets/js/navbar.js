// navbar.js
function toggleMenu() {
  const navbarMenu = document.querySelector(".navbar-menu");
  navbarMenu.classList.toggle("active");
}

// اضافه کردن کلاس active به لینک صفحه فعلی
document.addEventListener("DOMContentLoaded", function () {
  const currentPage = window.location.pathname.split("/").pop();
  const navLinks = document.querySelectorAll(".navbar-menu li a");

  navLinks.forEach((link) => {
    if (link.getAttribute("href") === currentPage) {
      link.classList.add("active");
    }
  });

  // نمایش تعداد محصولات از کوکی
  updateCartCountFromCookie();
});

// بارگذاری Navbar به صورت پویا
document.addEventListener("DOMContentLoaded", function () {
  const navbarContainer = document.getElementById("navbar-container");
  if (navbarContainer) {
    fetch("./navbar.html")
      .then((response) => response.text())
      .then((data) => {
        navbarContainer.innerHTML = data;
        // پس از بارگذاری نوار ناوبری، تعداد محصولات را به‌روزرسانی کنید
        updateCartCountFromCookie();
      });
  }
});

// تابع برای به‌روزرسانی تعداد محصولات از کوکی
function updateCartCountFromCookie() {
  const cartCountElement = document.getElementById("cart-count");

  // دریافت کوکی سبد خرید
  const cartCookie = document.cookie
    .split("; ")
    .find((row) => row.startsWith("cart="));

  if (cartCookie) {
    // استخراج مقدار کوکی
    const cartData = JSON.parse(decodeURIComponent(cartCookie.split("=")[1]));
    const cartItems = cartData.items || [];
    console.log("Cart Items:", cartItems); // برای دیباگ

    // نمایش تعداد محصولات
    if (cartCountElement) {
      cartCountElement.textContent = cartItems.length;
    }
  } else {
    // اگر کوکی وجود نداشت، تعداد را ۰ نمایش دهید
    if (cartCountElement) {
      cartCountElement.textContent = "0";
    }
  }
}