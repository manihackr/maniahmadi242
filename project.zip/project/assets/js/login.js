window.onload = function () {
    const pass = document.getElementById("password");
    const showb = document.getElementById("showb");
  
    // تنظیم ارتفاع دکمه نمایش متناسب با فیلد رمز عبور
    if (pass && showb) {
      showb.style.height = `${pass.offsetHeight}px`;
    }
  
    // نمایش/مخفی کردن رمز عبور
    if (showb) {
      showb.addEventListener("click", function () {
        if (pass.type === "password") {
          pass.type = "text";
          showb.innerText = "🙈";
        } else {
          pass.type = "password";
          showb.innerText = "👀";
        }
      });
    }
  };
  
  // اعتبارسنجی فرم
  function validateForm(event) {
    const username = document.getElementById("username").value;
    const password = document.getElementById("password").value;
  
    // اعتبارسنجی نام کاربری
    if (username.length < 8) {
      alert("نام کاربری باید حداقل 8 کاراکتر باشد.");
      event.preventDefault();
      return false;
    }
  
    // اعتبارسنجی رمز عبور
    if (password.length < 8) {
      alert("رمز عبور باید حداقل 8 کاراکتر باشد.");
      event.preventDefault();
      return false;
    }
  
    // اگر همه چیز درست بود، فرم ارسال می‌شود
    return true;
  }