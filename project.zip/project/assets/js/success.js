document.addEventListener("DOMContentLoaded", function () {
  // دریافت اطلاعات سبد خرید از localStorage
  const cartItems = JSON.parse(localStorage.getItem("cartItems")) || [];

  // نمایش جزئیات سفارش
  const orderDetails = document.getElementById("order-details");
  if (orderDetails) {
    if (cartItems.length === 0) {
      orderDetails.innerHTML = "<p>هیچ سفارشی یافت نشد.</p>";
    } else {
      let total = 0;
      orderDetails.innerHTML = "<h3>جزئیات سفارش:</h3>";
      cartItems.forEach((item) => {
        orderDetails.innerHTML += `<p>${item.name} - ${item.price.toLocaleString()} تومان</p>`;
        total += item.price;
      });
      orderDetails.innerHTML += `<p><strong>مجموع پرداختی: ${total.toLocaleString()} تومان</strong></p>`;

      // ذخیره اطلاعات خرید در کوکی (به مدت 1 روز)
      document.cookie = `purchasedItems=${JSON.stringify(cartItems)}; path=/; max-age=86400`;
    }
  }

  // حذف اطلاعات از localStorage
  localStorage.removeItem("cartItems");

  // حذف کوکی بعد از نمایش
  document.cookie = "purchasedItems=; path=/; expires=Thu, 01 Jan 1970 00:00:00 UTC";
});
