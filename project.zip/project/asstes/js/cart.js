// cart.js
// تابع برای دریافت کوکی
function getCookie(name) {
  const value = `; ${document.cookie}`;
  const parts = value.split(`; ${name}=`);
  if (parts.length === 2) return parts.pop().split(";").shift();
}

// تابع برای تنظیم کوکی
function setCookie(name, value, days) {
  const date = new Date();
  date.setTime(date.getTime() + days * 24 * 60 * 60 * 1000);
  const expires = `expires=${date.toUTCString()}`;
  document.cookie = `${name}=${value};${expires};path=/`;
}

// تابع برای بارگذاری سبد خرید
function loadCart() {
  const cartItems = JSON.parse(getCookie("cart") || "[]");
  const cartItemsList = document.getElementById("cart-items");

  // پاک کردن موارد قبلی
  cartItemsList.innerHTML = "";

  // بررسی اگر سبد خرید خالی است
  if (cartItems.length === 0) {
    cartItemsList.innerHTML = "<li>سبد خرید شما خالی است.</li>";
  } else {
    // نمایش موارد سبد خرید
    cartItems.forEach((item, index) => {
      const li = document.createElement("li");
      li.innerHTML = `${item.name} - ${item.price.toLocaleString()} تومان 
            <button class="remove-btn" onclick="removeFromCart(${index})">حذف</button>`;
      cartItemsList.appendChild(li);
    });
  }
}

// تابع برای حذف آیتم از سبد خرید
function removeFromCart(index) {
  let cartItems = JSON.parse(getCookie("cart") || "[]");
  cartItems.splice(index, 1); // حذف آیتم از آرایه
  setCookie("cart", JSON.stringify(cartItems), 7); // به‌روزرسانی کوکی
  loadCart(); // بارگذاری مجدد سبد خرید
}

// تابع برای هدایت به صفحه پرداخت
function redirectToPayment() {
  // دریافت اطلاعات سبد خرید از کوکی
  const cartItems = JSON.parse(getCookie("cart") || "[]");

  // اگر سبد خرید خالی باشد، کاربر را هدایت نکنید
  if (cartItems.length === 0) {
    alert("سبد خرید شما خالی است!");
    return;
  }

  // ذخیره اطلاعات سبد خرید در localStorage برای استفاده در صفحه پرداخت
  localStorage.setItem("cartItems", JSON.stringify(cartItems));

  // هدایت به صفحه پرداخت
  window.location.href = "./payment.html";
}

// بارگذاری سبد خرید هنگام لود صفحه
window.onload = loadCart;