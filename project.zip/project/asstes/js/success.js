// success.js
document.addEventListener("DOMContentLoaded", function () {
    // دریافت اطلاعات سبد خرید از localStorage
    const cartItems = JSON.parse(localStorage.getItem("cartItems")) || [];
  
    // نمایش جزئیات سفارش
    const orderDetails = document.getElementById("order-details");
    if (orderDetails) {
      if (cartItems.length === 0) {
        orderDetails.innerHTML = "<p>هیچ سفارشی یافت نشد.</p>";
      } else {
        let total = 0;
        orderDetails.innerHTML = "<h3>جزئیات سفارش:</h3>";
        cartItems.forEach((item) => {
          orderDetails.innerHTML += `<p>${item.name} - ${item.price} تومان</p>`;
          total += item.price;
        });
        orderDetails.innerHTML += `<p><strong>مجموع پرداختی: ${total} تومان</strong></p>`;
      }
    }
  
    // پاک کردن اطلاعات سبد خرید از localStorage پس از نمایش
    localStorage.removeItem("cartItems");
  });