// payment.js
document.addEventListener("DOMContentLoaded", function () {
  // دریافت اطلاعات سبد خرید از localStorage
  const cartItems = JSON.parse(localStorage.getItem("cartItems")) || [];

  // نمایش اطلاعات سبد خرید
  const cartSummary = document.getElementById("cart-summary");
  const amountInput = document.getElementById("amount");

  if (cartSummary && amountInput) {
    if (cartItems.length === 0) {
      cartSummary.innerHTML = "<p>سبد خرید شما خالی است.</p>";
    } else {
      let total = 0;
      cartSummary.innerHTML = "<h3>سبد خرید شما:</h3>";
      cartItems.forEach((item) => {
        cartSummary.innerHTML += `<p>${item.name} - ${item.price.toLocaleString()} تومان</p>`;
        total += item.price;
      });
      cartSummary.innerHTML += `<p><strong>مجموع: ${total.toLocaleString()} تومان</strong></p>`;

      // پر کردن خودکار فیلد مبلغ
      amountInput.value = total;
    }
  }

  // اعتبارسنجی فرم پرداخت
  const paymentForm = document.getElementById("payment-form");
  if (paymentForm) {
    paymentForm.addEventListener("submit", function (e) {
      e.preventDefault();

      // اعتبارسنجی شماره کارت
      const cardNumber = document.getElementById("card-number").value;
      if (cardNumber.length !== 16 || isNaN(cardNumber)) {
        alert("شماره کارت باید 16 رقم باشد.");
        return;
      }

      // اعتبارسنجی تاریخ انقضا
      const expiryDate = document.getElementById("expiry-date").value;
      if (!/^\d{2}\/\d{2}$/.test(expiryDate)) {
        alert("تاریخ انقضا باید به فرمت MM/YY باشد.");
        return;
      }

      // اعتبارسنجی CVV
      const cvv = document.getElementById("cvv").value;
      if (cvv.length !== 3 || isNaN(cvv)) {
        alert("CVV باید 3 رقم باشد.");
        return;
      }

      // اگر همه چیز درست بود، فرم ارسال می‌شود
      alert("پرداخت با موفقیت انجام شد!");

      // پاک کردن سبد خرید از localStorage و کوکی
      localStorage.removeItem("cartItems");
      document.cookie = "cart=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";

      // هدایت به صفحه موفقیت
      window.location.href = "./success.html";
    });
  }
});