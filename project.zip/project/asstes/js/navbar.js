// navbar.js
function toggleMenu() {
  const navbarMenu = document.querySelector(".navbar-menu");
  navbarMenu.classList.toggle("active");
}

// اضافه کردن کلاس active به لینک صفحه فعلی
document.addEventListener("DOMContentLoaded", function () {
  const currentPage = window.location.pathname.split("/").pop();
  const navLinks = document.querySelectorAll(".navbar-menu li a");

  navLinks.forEach((link) => {
    if (link.getAttribute("href") === currentPage) {
      link.classList.add("active");
    }
  });
});
// بارگذاری Navbar به صورت پویا
document.addEventListener("DOMContentLoaded", function () {
  const navbarContainer = document.getElementById("navbar-container");
  if (navbarContainer) {
    fetch("./navbar.html")
      .then((response) => response.text())
      .then((data) => {
        navbarContainer.innerHTML = data;
      });
  }
});