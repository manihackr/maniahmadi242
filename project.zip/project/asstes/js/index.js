// تابع برای دریافت کوکی
function getCookie(name) {
  const value = `; ${document.cookie}`;
  const parts = value.split(`; ${name}=`);
  if (parts.length === 2) return parts.pop().split(";").shift();
}

// تابع برای تنظیم کوکی
function setCookie(name, value, days) {
  const date = new Date();
  date.setTime(date.getTime() + days * 24 * 60 * 60 * 1000);
  const expires = `expires=${date.toUTCString()}`;
  document.cookie = `${name}=${value};${expires};path=/`;
}

// تابع برای افزودن محصول به سبد خرید
function addToCart(productName, productPrice) {
  const product = { name: productName, price: productPrice };
  let cartItems = JSON.parse(getCookie("cart") || "[]");
  cartItems.push(product);
  setCookie("cart", JSON.stringify(cartItems), 7); // ذخیره سبد خرید در کوکی برای 7 روز
  alert(`${productName} به سبد خرید اضافه شد!`);
  showCart(); // نمایش سبد خرید پس از افزودن محصول
}

// تابع برای نمایش سبد خرید
function showCart() {
  const cartModal = document.getElementById("cart-modal");
  const cartItemsList = document.getElementById("cart-items");

  // پاک کردن موارد قبلی
  cartItemsList.innerHTML = "";

  // بارگذاری موارد سبد خرید از کوکی
  let cartItems = JSON.parse(getCookie("cart") || "[]");

  // بررسی اگر سبد خرید خالی است
  if (cartItems.length === 0) {
    cartItemsList.innerHTML = "<li>سبد خرید شما خالی است.</li>";
  } else {
    // نمایش موارد سبد خرید
    cartItems.forEach((item, index) => {
      const li = document.createElement("li");
      li.innerHTML = `${item.name} - ${item.price.toLocaleString()} تومان 
            <button class="remove-btn" onclick="removeFromCart(${index})">حذف</button>`;
      cartItemsList.appendChild(li);
    });
  }

  cartModal.style.display = "block";
}

// تابع برای حذف آیتم از سبد خرید
function removeFromCart(index) {
  let cartItems = JSON.parse(getCookie("cart") || "[]");
  cartItems.splice(index, 1); // حذف آیتم از آرایه
  setCookie("cart", JSON.stringify(cartItems), 7); // به‌روزرسانی کوکی
  showCart(); // بارگذاری مجدد سبد خرید
}

// تابع برای بستن مودال سبد خرید
function closeCart() {
  const cartModal = document.getElementById("cart-modal");
  cartModal.style.display = "none";
}

// داده‌های محصولات
const products = [
  { name: "پیتزا", price: 350000, image: "./assets/image/pizza.jpg" },
  { name: "همبرگر", price: 300000, image: "./assets/image/hamburger.jpg" },
  { name: "کوکاکولا", price: 40000, image: "./assets/image/cocacola.jpg" },
  { name: "سالاد فصل", price: 150000, image: "./assets/image/salad.jpg" },
  { name: "سیب‌زمینی سرخ‌کرده", price: 100000, image: "./assets/image/sibzamini.jpg" },
  { name: "دوغ", price: 20000, image: "./assets/image/dogh.jpg" },
  { name: "ساندویچ مرغ", price: 250000, image: "./assets/image/chicken_sandwich.jpg" },
  { name: "پاستا", price: 200000, image: "./assets/image/pasta.jpg" },
  { name: "نوشابه", price: 30000, image: "./assets/image/soda.jpg" },
  { name: "چیزبرگر", price: 280000, image: "./assets/image/cheeseburger.jpg" },
];

// نمایش محصولات
function renderProducts(products) {
  const container = document.getElementById("products-container");
  container.innerHTML = "";
  products.forEach((product) => {
    const card = document.createElement("div");
    card.className = "product-card";
    card.innerHTML = `
      <img src="${product.image}" alt="${product.name}" />
      <h3>${product.name}</h3>
      <p>قیمت: ${product.price.toLocaleString()} تومان</p>
      <button onclick="addToCart('${product.name}', ${product.price})">
        افزودن به سبد خرید
      </button>
    `;
    container.appendChild(card);
  });
}

// فیلتر محصولات بر اساس جست‌وجو
function filterProducts() {
  const searchTerm = document.getElementById("search-input").value.toLowerCase();
  const filteredProducts = products.filter((product) =>
    product.name.toLowerCase().includes(searchTerm)
  );
  renderProducts(filteredProducts);
}

// بارگذاری اولیه محصولات
renderProducts(products);

// اضافه کردن انیمیشن به دکمه‌ها
document.querySelectorAll('.product-card button').forEach(button => {
  button.addEventListener('mouseenter', () => {
    button.style.transform = 'scale(1.1)';
  });
  button.addEventListener('mouseleave', () => {
    button.style.transform = 'scale(1)';
  });
});