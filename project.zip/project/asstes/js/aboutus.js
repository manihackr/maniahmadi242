// aboutus.js
document.addEventListener("DOMContentLoaded", function () {
    const backButton = document.querySelector(".btn-dark");
  
    if (backButton) {
      backButton.addEventListener("click", function (e) {
        e.preventDefault();
        alert("در حال بازگشت به صفحه اصلی...");
        window.location.href = "index.html";
      });
    }
  });